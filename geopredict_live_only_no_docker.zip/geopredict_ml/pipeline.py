from __future__ import annotations

import math
from pathlib import Path
from typing import Any

from .business import BusinessProfile, resolve_business_profile
from .explain import build_explanation, build_explanation_summary
from .features import compute_cell_features, normalize_geojson_pois, saturating_count
from .geo import clamp
from .grid import GridCell, polygon_to_grid_cells, validate_polygon_geometry
from .model import GradientBoostingRegressorLite, train_reference_model
from .model_registry import load_explicit_model, load_model_for_profile, model_artifact_path


def analyze_request(
    request_payload: dict[str, Any],
    pois_geojson: dict | None = None,
    model_path: str | Path | None = None,
    max_cells: int = 1_000,
    data_sources: list[str] | None = None,
    data_warnings: list[str] | None = None,
    data_fetched_at: float | None = None,
) -> dict[str, Any]:
    geometry = request_payload.get("geometry")
    validate_polygon_geometry(geometry)

    requested_business_type = request_payload.get("business_type")
    if not requested_business_type:
        raise ValueError("business_type is required")
    business_type = requested_business_type
    if str(requested_business_type) == "custom_osm":
        business_type = request_payload.get("business_query")
        if not business_type or len(str(business_type).strip()) < 2:
            raise ValueError("business_query is required when business_type is custom_osm")

    resolution = int(request_payload.get("h3_resolution", 9))
    allow_custom_business = bool(request_payload.get("allow_custom_business", True))
    profile = resolve_business_profile(str(business_type), allow_custom=allow_custom_business)
    cells = polygon_to_grid_cells(geometry, resolution=resolution, max_cells=max_cells)
    pois = normalize_geojson_pois(pois_geojson)
    resolved_data_sources = data_sources if data_sources is not None else (["osm"] if pois_geojson else [])
    resolved_data_warnings = data_warnings or []
    feature_rows = [compute_cell_features(cell, pois, profile) for cell in cells]
    model, model_source, artifact_path = _load_or_train_model(profile, model_path)
    model_predictions = model.predict(feature_rows)
    candidate_scores = [_candidate_score(row, score) for row, score in zip(feature_rows, model_predictions)]
    ranked_predictions = _rank_candidates(cells, feature_rows, candidate_scores)
    recommendations_available = bool(pois)

    features = []
    for cell, row, raw_score, candidate in zip(cells, feature_rows, model_predictions, candidate_scores):
        rank_info = ranked_predictions[cell.h3_id]
        recommendation = (
            _recommendation_for_candidate(candidate, rank_info["rank"], len(cells))
            if recommendations_available
            else {"code": "insufficient_data", "label": "Недостаточно данных"}
        )
        properties = {
            "h3_id": cell.h3_id,
            "rank": rank_info["rank"],
            "total_candidates": len(cells),
            "top_percentile": round(rank_info["rank"] / max(1, len(cells)), 4),
            "suitability": round(candidate["selection_score"], 3),
            "success_probability": round(candidate["selection_score"], 3),
            "model_score": round(raw_score, 3),
            "selection_score": round(candidate["selection_score"], 3),
            "data_confidence": round(candidate["data_confidence"], 3),
            "recommendation": recommendation["code"],
            "recommendation_label": recommendation["label"],
            "competition": row["competition"],
            "competition_metric": "competitor_poi_count_within_radius",
            "competition_radius_m": profile.radius_m,
            "competition_soft_limit": profile.competition_soft_limit,
            "norm_competition": round(float(row["norm_competition"]), 3),
            "competition_penalty": round(float(row["competition_penalty"]), 3),
            "market_validation": round(float(row["market_validation"]), 3),
            "traffic_potential": round(float(row["traffic_potential"]), 3),
            "density_score": round(float(row["density_score"]), 3),
            "poi_counts": row["poi_counts"],
            "explanation": build_explanation(row, candidate["selection_score"], profile),
            "explanation_summary": build_explanation_summary(
                row,
                candidate["selection_score"],
                profile,
            ),
        }
        features.append({"type": "Feature", "geometry": cell.geometry, "properties": properties})

    selection_scores = [candidate["selection_score"] for candidate in candidate_scores]
    avg_suitability = round(sum(selection_scores) / len(selection_scores), 3) if selection_scores else 0.0
    avg_model_score = round(sum(model_predictions) / len(model_predictions), 3) if model_predictions else 0.0
    grid_backend = cells[0].backend if cells else "unknown"
    top_candidates = (
        _top_candidates(
            cells,
            feature_rows,
            model_predictions,
            candidate_scores,
            ranked_predictions,
            profile,
        )
        if recommendations_available
        else []
    )
    recommendation_counts = (
        _recommendation_counts(cells, candidate_scores, ranked_predictions)
        if recommendations_available
        else {
            "high_priority": 0,
            "promising": 0,
            "manual_review": 0,
            "low_priority": 0,
            "insufficient_data": len(cells),
        }
    )

    return {
        "type": "FeatureCollection",
        "features": features,
        "metadata": {
            "total_hexagons": len(features),
            "h3_resolution": resolution,
            "avg_suitability": avg_suitability,
            "avg_model_score": avg_model_score,
            "business_type": profile.business_type,
            "business_title": profile.title,
            "business_category": profile.category,
            "business_query": profile.source_query,
            "is_custom_business": profile.is_custom,
            "business_interpretation": {
                "mode": "custom_osm" if profile.is_custom else "fixed_profile",
                "requested": str(requested_business_type),
                "source_query": profile.source_query,
                "resolved_business_type": profile.business_type,
                "title": profile.title,
                "osm_tags": [
                    {"key": key, "value": value}
                    for key, value in profile.competitor_tags
                ],
                "osm_keywords": list(profile.competitor_keywords[:12]),
            },
            "data_sources": resolved_data_sources,
            "data_status": _data_status(resolved_data_sources, len(pois)),
            "data_warnings": resolved_data_warnings,
            "data_fetched_at": data_fetched_at,
            "poi_count": len(pois),
            "recommendations_available": recommendations_available,
            "model_active": True,
            "model_type": model.model_type,
            "model_version": model.model_version,
            "model_source": model_source,
            "model_artifact_path": artifact_path,
            "target_type": "proxy_location_success",
            "grid_backend": grid_backend,
            "top_candidates": top_candidates,
            "recommendation_counts": recommendation_counts,
            "selection_policy": "strict_v2_rank_confidence_saturation",
        },
    }


def _load_or_train_model(
    profile: BusinessProfile,
    model_path: str | Path | None,
) -> tuple[GradientBoostingRegressorLite, str, str | None]:
    if model_path and Path(model_path).exists():
        return load_explicit_model(model_path, profile), "explicit_artifact", str(model_path)

    registered_model = load_model_for_profile(profile)
    if registered_model:
        return registered_model, "registered_artifact", str(model_artifact_path(profile))

    return train_reference_model(profile), "reference_in_memory", None


def _data_status(data_sources: list[str], poi_count: int) -> str:
    if "mock_sample" in data_sources:
        return "mock"
    if not poi_count:
        return "insufficient"
    if "osm_cache" in data_sources or "osm_cache_stale" in data_sources:
        return "cached"
    if "osm_live" in data_sources or "osm" in data_sources:
        return "live"
    return "unknown"


def _candidate_score(features: dict[str, Any], model_score: float) -> dict[str, float]:
    traffic = float(features.get("traffic_potential", 0.0))
    density = float(features.get("density_score", 0.0))
    residential = float(features.get("residential_score", 0.0))
    transport = float(features.get("transport_score", 0.0))
    retail = float(features.get("retail_anchor_score", 0.0))
    office = float(features.get("office_score", 0.0))
    nearby_total = float(features.get("nearby_poi_total", 0.0))
    norm_competition = float(features.get("norm_competition", 0.0))
    competition_penalty = float(features.get("competition_penalty", 0.0))

    data_confidence = clamp(
        0.36 * density
        + 0.18 * traffic
        + 0.15 * residential
        + 0.12 * transport
        + 0.11 * retail
        + 0.08 * saturating_count(nearby_total, 12.0)
    )
    base_score = clamp(
        0.34 * model_score
        + 0.18 * traffic
        + 0.16 * residential
        + 0.13 * retail
        + 0.10 * density
        + 0.06 * transport
        + 0.03 * office
    )
    saturation_penalty = 0.16 * competition_penalty + 0.08 * max(0.0, norm_competition - 0.55)
    uncertainty_penalty = 0.20 * (1.0 - data_confidence)
    weak_signal_penalty = 0.06 if traffic + residential + retail < 0.55 else 0.0

    return {
        "selection_score": clamp(base_score - saturation_penalty - uncertainty_penalty - weak_signal_penalty),
        "data_confidence": data_confidence,
    }


def _rank_candidates(
    cells: list[GridCell],
    feature_rows: list[dict[str, Any]],
    candidate_scores: list[dict[str, float]],
) -> dict[str, dict[str, int]]:
    ordered = sorted(
        zip(cells, feature_rows, candidate_scores),
        key=lambda item: (
            -item[2]["selection_score"],
            -item[2]["data_confidence"],
            -float(item[1].get("traffic_potential", 0.0)),
            -float(item[1].get("residential_score", 0.0)),
            float(item[1].get("competition_penalty", 0.0)),
            item[0].h3_id,
        ),
    )
    return {cell.h3_id: {"rank": rank} for rank, (cell, _row, _score) in enumerate(ordered, start=1)}


def _recommendation_for_candidate(candidate: dict[str, float], rank: int, total_cells: int) -> dict[str, str]:
    score = candidate["selection_score"]
    data_confidence = candidate["data_confidence"]
    high_priority_limit = max(3, math.ceil(total_cells * 0.02))
    promising_limit = max(10, math.ceil(total_cells * 0.18))

    if score >= 0.70 and data_confidence >= 0.30 and rank <= high_priority_limit:
        return {"code": "high_priority", "label": "Приоритетно рассмотреть"}
    if score >= 0.54 and data_confidence >= 0.22 and rank <= promising_limit:
        return {"code": "promising", "label": "Перспективная зона"}
    if score >= 0.34 and data_confidence >= 0.12:
        return {"code": "manual_review", "label": "Нужна ручная проверка"}
    return {"code": "low_priority", "label": "Низкий приоритет"}


def _top_candidates(
    cells: list[GridCell],
    feature_rows: list[dict[str, Any]],
    model_predictions: list[float],
    candidate_scores: list[dict[str, float]],
    ranks: dict[str, dict[str, int]],
    profile: BusinessProfile,
    limit: int = 10,
) -> list[dict[str, Any]]:
    ordered = sorted(
        zip(cells, feature_rows, model_predictions, candidate_scores),
        key=lambda item: ranks[item[0].h3_id]["rank"],
    )
    candidates = []
    for cell, row, model_score, candidate in ordered[:limit]:
        rank = ranks[cell.h3_id]["rank"]
        recommendation = _recommendation_for_candidate(candidate, rank, len(cells))
        candidates.append(
            {
                "h3_id": cell.h3_id,
                "rank": rank,
                "total_candidates": len(cells),
                "suitability": round(candidate["selection_score"], 3),
                "model_score": round(model_score, 3),
                "data_confidence": round(candidate["data_confidence"], 3),
                "recommendation": recommendation["code"],
                "competition": row["competition"],
                "competition_radius_m": profile.radius_m,
                "traffic_potential": round(float(row["traffic_potential"]), 3),
                "density_score": round(float(row["density_score"]), 3),
                "poi_counts": row["poi_counts"],
                "explanation": build_explanation(row, candidate["selection_score"], profile),
                "explanation_summary": build_explanation_summary(
                    row,
                    candidate["selection_score"],
                    profile,
                ),
                "center": {"lon": round(cell.center_lon, 7), "lat": round(cell.center_lat, 7)},
            }
        )
    return candidates


def _recommendation_counts(
    cells: list[GridCell],
    candidate_scores: list[dict[str, float]],
    ranks: dict[str, dict[str, int]],
) -> dict[str, int]:
    counts = {
        "high_priority": 0,
        "promising": 0,
        "manual_review": 0,
        "low_priority": 0,
    }
    total_cells = len(candidate_scores)
    for cell, candidate in zip(cells, candidate_scores):
        rank = ranks[cell.h3_id]["rank"]
        counts[_recommendation_for_candidate(candidate, rank, total_cells)["code"]] += 1
    return counts
