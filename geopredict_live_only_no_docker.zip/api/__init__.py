"""API entrypoints for GeoPredict."""
